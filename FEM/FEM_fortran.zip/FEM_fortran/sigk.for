      SUBROUTINE SIGKE3(U,X,T,NF,I,NUX,NMS,FI,SIK,ALF,EN,SN)
      DOUBLE PRECISION U,X,T,W,V,GK,GN,SIK,
     ,XE,UE,CK,UK,FI,FII,CNT,CN,SIG,SS,DET,A1,A2,A3,
     ,TT,AL,AA,ALFAT,ALF,AN,EN,D,DX,CKT,CK0,SN
      COMMON/KSO/M,N,LLL,LL(5)
      COMMON/JN64/NN(64)
c      COMMON/A1/A1
      COMMON/DET/D
      COMMON/DX/DX(3)
      DIMENSION U(1),X(1),T(1),NF(1),LA(8),MA(8),
     ,XE(24),UE(24),W(24),FI(3,3),AL(64),CKT(3,3),CK0(3,3),
     ,FII(3,3),CK(3,3),CNT(3,3),CN(3,3),SIG(3,3),SN(3,3),
     ,UK(3,3),V(24),EN(3,3),GK(3,3),GN(3,3),SIK(3,3)
      NN(1)=I
      M=2
      N=2
      LLL=2
      A1=0.D0
      A2=0.D0
      A3=0.D0
      CALL ALPRO(AL,8,LA,MA)
      CALL PNTPRO(I,1)
      TT=0.D0
      DO 2 J=1,8
      NU1=NN(J)
      NU2=NU1+NUX
      NU3=NU2+NUX
      MU1=J
      MU2=MU1+8
      MU3=MU2+8
      TT=TT+T(NU1)
      XE(MU1)=X(NU1)
      UE(MU1)=U(NU1)
      XE(MU2)=X(NU2)
      UE(MU2)=U(NU2)
      XE(MU3)=X(NU3)
      UE(MU3)=U(NU3)
    2 CONTINUE
      TT=TT*0.125D0
      ALF=TT*ALFAT(TT)
      CALL WPRO(W(1),8,XE(1),AL)
      CALL WPRO(W(9),8,XE(9),AL)
      CALL WPRO(W(17),8,XE(17),AL)
      CALL WPRO(V(1),8,UE(1),AL)
      CALL WPRO(V(9),8,UE(9),AL)
      CALL WPRO(V(17),8,UE(17),AL)
      CALL CKPRO(CK,4,8,W,A1,A2,A3)
      CALL CKPRO(UK,4,8,V,A1,A2,A3)
      CALL OBRM33(CK,CN)
      DET=D
      CALL TRAN33(CN,CNT)
      CALL TRAN33(CK,CKT)
      CALL GKN(GK,GN,CK)
      DO 11 I1=1,3
      DO 11 J1=1,3
   11 CK0(I1,J1)=CK(I1,J1)/DSQRT(GK(J1,J1))
      DO 10 IA=1,3
      DO 10 JA=1,3
      AN=0.D0
      AA=0.D0
      DO 20 KK=1,3
      AA=AA+UK(KK,IA)*CK(KK,JA)+
     +UK(KK,JA)*CK(KK,IA)
      AN=AN+UK(KK,IA)*UK(KK,JA)
   20 CONTINUE
      FI(IA,JA)=AA*0.5D0
      EN(IA,JA)=AN*0.5D0
   10 CONTINUE
      CALL SIGDEK(FI,FII,CNT)
      CALL TRAN33(FII,FI) 
      CALL SIGARM(FII,CK0)
      CALL SIGMA3(FII,SIG,CK0,TT)
      DO 5 I1=1,3
      DO 5 J1=1,3
      SS=0.D0
      DO 6 K1=1,3
      DO 6 L1=1,3
    6 SS=SS+SIG(K1,L1)*CK(L1,I1)*CK(K1,J1)
    5 SIK(I1,J1)=SS
      DO 54 II=1,3
      DO 54 J=1,3
  54  SIK(II,J)=SIK(II,J)*DSQRT(GN(II,II)*GN(J,J))
      RETURN
      END