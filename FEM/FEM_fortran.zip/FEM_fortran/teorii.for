      SUBROUTINE UABOLINSH           
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,QK1,EK,GCR 
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      PARG1=EC/(2.D0*(1.D0+VC))
      PARG2=ER/(2.D0*(1.D0+VR))
      QK1=3.D0-4.D0*VR
      EK=EC/ER
      GCR=PARG1/PARG2
      E11=EC*C1+ER*C2
      E22=(EK*E11)/((C1+EK*C2)*(1.D0+(EK-1.D0)*C1)-
     -(EK*VR-VC)**2.D0*C1*C2)
      E33=E22
      G12=(GCR*(1.D0+C1)+1.D0-C1)/(GCR*(1.D0-C1)+1.D0+C1)*PARG2
      G13=G12
      G23=PARG2*GCR/(C1+GCR*C2)
      V12=VC*C1+VR*C2
      V21=E22*V12/E11
      V13=V12
      V23=E22/(2.D0*G23)-1.D0
      V31=E33*V13/E11
      V32=V23
      WRITE(4,*)'������ ���������'
      RETURN
      END
      SUBROUTINE UENERG         
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION VC13,VC21,VC31,VC32,GC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION ALFA,BETA,EC3,EKO,PARG2
      DOUBLE PRECISION S11,S12,S22,S23,D1,D2,D,D3,D4,S2,S55
      DOUBLE PRECISION A11,A12,A21,A22
      DOUBLE PRECISION B1,S3
      DOUBLE PRECISION H00,H01,H02,H12,H22,H11 
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      VC13=VC12
      VC21=EC22*VC12/EC11
      VC31=VC21
      VC32=VC23
      GC23=EC22/(2.D0*(1.D0+VC23))
      PARG2=ER/(2.D0*(1.D0+VR))
      ALFA=EC/ER
      BETA=VR/ER*EC
      EC3=EC22
      EKO=EC3/EC
C
      A11=(1.D0-VC23)*C2+ALFA*EKO*(1.D0+C1)+BETA*EKO*C2
      A12=VC21*C2+BETA*EKO*C1
      A21=2.D0*BETA*C1+2.D0*VC21*C2
      A22=ALFA*C1+C2
      D1=A22*VC21-A12
      D2=A11-A21*VC21
      D=A11*A22-A12*A21
      S11=(ALFA*D2+2.D0*BETA*D1)/D/EC
      E11=1.D0/S11
      S12=-(2.D0*ALFA*D1+BETA*D2)/D/EC
      V12=-S12/S11
      D3=A22*(ALFA*EKO*(1.D0-VR)-(1.D0-VC23))*C1-2.D0*A12*(BETA-VC12)*C1
      D4=2.D0*A11*(BETA-VC12)*C1-A21*(ALFA*EKO*(1.D0-VR)-(1.D0-VC23))*C1
      S2=(ALFA-BETA-(2.D0*ALFA*D3+BETA*D4)/D)/EC
      S12=-(BETA-(0.5D0*ALFA*D4+BETA*D3)/D)/EC
      S55=(GC12*C2+PARG2*(1.D0+C1))/(GC12*(1.D0+C1)+PARG2*C2)/PARG2
      G12=1.D0/S55
      A11=3.D0*(1.D0+VC23)*(1.D0/C1**2-1.D0)+4.D0*(VC23+VC12*VC21)*
     *(C1-1.D0/C1**2)+ALFA*EKO*(1.D0+VR)*(3.D0-4.D0*VR*C1+1.D0/C1**2)
      A12=2.D0*(1.D0+VC23)*(1.D0/C1-1.D0)+2.D0*(VC23+VC12*VC21)*
     *(C1-1.D0/C1)+2.D0*ALFA*EKO*(1.D0+VR)*(1.D0-VR*C1+(1.D0-VR)/C1)
      A21=3.D0*(1.D0+VC23)*(1.D0/C1**2-1.D0)+2.D0*(3.D0+VC23-
     -2.D0*VC12*VC21)*(C1-1.D0/C1**2)+ALFA*EKO*(3.D0*(1.D0+VR)-
     -2.D0*(3.D0+VR-2.D0*VR**2)*C1-(1.D0+VR)/C1**2)
      A22=2.D0*(1.D0+VC23)*(1.D0/C1-1.D0)+(3.D0+VC23-2.D0*VC12*VC21)*
     *(C1-1.D0/C1)+ALFA*EKO*(2.D0*(1.D0+VR)-(3.D0+VR-2.D0*VR**2)*C1+
     +(1.D0-VR-2.D0*VR**2)/C1)
      B1=(1.D0+VC23)-ALFA*EKO*(1.D0+VR)
      D1=B1*(A22-A12)
      D2=B1*(A11-A21)
      D=A11*A22-A12*A21
C
c      H00=(ALFA*(1.D0+VR)*(1-C1))/(EC*EKO)
      H00=(ALFA*(1.D0+VR)*(1-C1))/EC
c      WRITE(4,*)'H00=',H00
      H01=(2.D0*(3.D0*EKO*ALFA*(1.D0+VR)*(C1**2-C1)+
     +(3.D0+VC23-2.D0*VC12*VC21)*(C1**2-1.D0/C1)))*D1/(EC*EKO*D)
c      WRITE(4,*)'H01=',H01
      H02=(EKO*ALFA*(1.D0+VR)*(3.D0*C1**2-4.D0*C1+1.D0)+
     +(3.D0+VC23-2.D0*VC12*VC21)*(C1**2-1.D0))*D2/(EC*EKO*D)
c      WRITE(4,*)'H02=',H02
      H12=(3.D0*EKO*ALFA*(1.D0+VR)*(1.D0/C1**2+7.D0*C1**2)-
     -6.D0*EKO*ALFA*(C1*(1.D0+3.D0*VR+2.D0*VR**2)+C1**3*(3.D0+VR-
     -2.D0*VR**2))+(3.D0+VC23-2.D0*VC12*VC21)*(1.D0/C1**2-4.D0/C1+
     +2.D0*C1+7.D0*C1**2-6.D0*C1**3))*D1*D2/(EC*EKO*D**2)
c      WRITE(4,*)'H12=',H12
      H11=(EKO*ALFA*(1.D0+VR)*(3.D0/C1**3-9.D0*C1+18.D0*C1**2)+
     +6.D0*EKO*ALFA*((1.D0-3.D0*C1**3)-VR*(1.D0+C1**3)+
     +2.D0*VR**2*(C1**3-1.D0))+(3.D0+VC23-2.D0*VC12*VC21)*(-6.D0/C1+
     +6.D0+6.D0*C1**2-6.D0*C1**3))*D1**2/(EC*EKO*D**2)
c      WRITE(4,*)'H11=',H11
      H22=(EKO*ALFA*((1.5D0/C1-2.D0-C1+6.D0*C1**2-4.5D0*C1**3)+
     +VR*(0.5D0/C1+2.D0-7.D0*C1+6.D0*C1**2-1.5D0*C1**3)+
     +VR**2*(-1.D0/C1+4.D0-6.D0*C1+3.D0*C1**3))+
     +(3.D0+VC23-2.D0*VC12*VC21)*
     *(0.5D0/C1-2.D0+C1+2.D0*C1**2-1.5D0*C1**3))*D2**2/(EC*EKO*D**2)
c      WRITE(4,*)'H22=',H22
      S3=H00+H01+H02+H12+H11+H22
c      WRITE(4,*)'s3=',s3
C
c      s3=0.167d0
      S22=(S2+S3)/2.D0
      S23=(S2-S3)/2.D0
      V23=-S23/S22
      E22=1.D0/S22
      E33=E22
      G13=G12
      V21=E22*V12/E11
      V13=V12
      G23=E22/(2.D0*(1.D0+V23))
      V31=E33*V13/E11
      V32=V23
c      WRITE(4,*)'������ ���������'
      RETURN
      END
      SUBROUTINE UKASPAROV         
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION VC13,VC21,VC31,VC32,GC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION AG,BG,FG,CG,EG,CA,CB,CF,CC,CE,AA,CCC,BB,EE,FF 
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      VC13=VC12
      VC21=EC22*VC12/EC11
      VC31=VC21
      VC32=VC23
      GC23=EC22/(2.D0*(1.D0+VC23))
      AG=ER/(2.D0*(1.D0-VR-2.D0*VR**2))
      BG=ER/(2.D0*(1.D0+VR))
      FG=BG
      CG=2.D0*VR*AG
      EG=2.D0*(1.D0-VR)*AG
      CA=EC/(2.D0*(1.D0-VC23-2.D0*VC**2))
      CB=EC/(2.D0*(1.D0+VC23))
      CF=GC12
      CC=2.D0*VC*CA
      CE=2.D0*(1.D0-VC23)*CA
      AA=(AG*(CA+BG)*C2+CA*(AG+BG)*C1)/((CA+BG)*C2+(AG+BG)*C1)
      CCC=(CG*(AA-CA)-CC*(AA-AG))/(AG-CA)
      BB=BG*(2.D0*C1*CB*(AG+BG)+2.D0*C2*CB*BG+C2*AG*(CB+BG))/
     /(2.D0*C1*BG*(AG+BG)+2.D0*C2*CB*BG+C2*AG*(CB+BG))
      EE=((CCC-CG)*(CCC-C1*CC-C2*CG)+(AA-AG)*(C1*CE+C2*EG))/(AA-AG)
      FF=(FG*(CF+FG)*C2+CF*2.D0*FG*C1)/((CF+FG)*C2+2.D0*FG*C1)
c
      E11=EE-CCC**2/AA
      E22=(4.D0*BB*(AA*EE-CCC**2))/((AA+BB)*EE-CCC**2)
      V12=CCC/(2.D0*AA)
      E33=E22
      G12=FF
      V23=((AA-BB)*EE-CCC**2)/((AA+BB)*EE-CCC**2)
      G23=BB
      G13=G12
      V21=E22*V12/E11
      V13=V12
      V31=E33*V13/E11
      V32=V23
      WRITE(4,*)'������ ���������'
      RETURN
      END

      SUBROUTINE UKLASTORNIO         
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION VC13,VC21,VC31,VC32,GC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION ALFA,BETA,EC3,EKO,PARG2
      DOUBLE PRECISION S11,S12,S22,S23,S3,D1,D2,D,D3,D4,S2,S55
      DOUBLE PRECISION A11,A12,A21,A22,B1
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      VC13=VC12
      VC21=EC22*VC12/EC11
      VC31=VC21
      VC32=VC23
      GC23=EC22/(2.D0*(1.D0+VC23))
      PARG2=ER/(2.D0*(1.D0+VR))
      ALFA=EC/ER
      BETA=VR/ER*EC
      EC3=EC22
      EKO=EC3/EC
C
      A11=(1.D0-VC23)*C2+ALFA*EKO*(1.D0+C1)+BETA*EKO*C2
      A12=VC21*C2+BETA*EKO*C1
      A21=2.D0*BETA*C1+2.D0*VC21*C2
      A22=ALFA*C1+C2
      D1=A22*VC21-A12
      D2=A11-A21*VC21
      D=A11*A22-A12*A21
      S11=(ALFA*D2+2.D0*BETA*D1)/D/EC
      E11=1.D0/S11
      S12=-(2.D0*ALFA*D1+BETA*D2)/D/EC
      V12=-S12/S11
      D3=A22*(ALFA*EKO*(1.D0-VR)-(1.D0-VC23))*C1-2.D0*A12*(BETA-VC12)*C1
      D4=2.D0*A11*(BETA-VC12)*C1-A21*(ALFA*EKO*(1.D0-VR)-(1.D0-VC23))*C1
      S2=(ALFA-BETA-(2.D0*ALFA*D3+BETA*D4)/D)/EC
      S12=-(BETA-(0.5D0*ALFA*D4+BETA*D3)/D)/EC
      S55=(GC12*C2+PARG2*(1.D0+C1))/(GC12*(1.D0+C1)+PARG2*C2)/PARG2
      G12=1.D0/S55
      A11=3.D0*(1.D0+VC23)*(1.D0/C1**2-1.D0)+4.D0*(VC23+VC12*VC21)*
     *(C1-1.D0/C1**2)+ALFA*EKO*(1.D0+VR)*(3.D0-4.D0*VR*C1+1.D0/C1**2)
      A12=2.D0*(1.D0+VC23)*(1.D0/C1-1.D0)+2.D0*(VC23+VC12*VC21)*
     *(C1-1.D0/C1)+2.D0*ALFA*EKO*(1.D0+VR)*(1.D0-VR*C1+(1.D0-VR)/C1)
      A21=3.D0*(1.D0+VC23)*(1.D0/C1**2-1.D0)+2.D0*(3.D0+VC23-
     -2.D0*VC12*VC21)*(C1-1.D0/C1**2)+ALFA*EKO*(3.D0*(1.D0+VR)-
     -2.D0*(3.D0+VR-2.D0*VR**2)*C1-(1.D0+VR)/C1**2)
      A22=2.D0*(1.D0+VC23)*(1.D0/C1-1.D0)+(3.D0+VC23-2.D0*VC12*VC21)*
     *(C1-1.D0/C1)+ALFA*EKO*(2.D0*(1.D0+VR)-(3.D0+VR-2.D0*VR**2)*C1+
     +(1.D0-VR-2.D0*VR**2)/C1)
      B1=(1.D0+VC23)-ALFA*EKO*(1.D0+VR)
      D1=B1*(A22-A12)
      D2=B1*(A11-A21)
      D=A11*A22-A12*A21
      S3=(ALFA+BETA)*(1.D0-4.D0*(1.D0-VR)*D1/D)/EC 
      S22=(S2+S3)/2.D0
      S23=(S2-S3)/2.D0
      V23=-S23/S22
      E22=1.D0/S22
      E33=E22
      G13=G12
      V21=E22*V12/E11
      V13=V12
      G23=E22/(2.D0*(1.D0+V23))
      V31=E33*V13/E11
      V32=V23
c      WRITE(4,*)'������ ���������'
      RETURN
      END

      SUBROUTINE UKLASTORNIR         
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION VC13,VC21,VC31,VC32,GC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION ALFA,BETA,EC3,EKO,PARG2
      DOUBLE PRECISION S11,S12,S22,S23,S3,D1,D2,D,D3,D4,S2,S55
      DOUBLE PRECISION A11,A12,A21,A22,B1
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      VC13=VC12
      VC21=EC22*VC12/EC11
      VC31=VC21
      VC32=VC23
      GC23=EC22/(2.D0*(1.D0+VC23))
      PARG2=ER/(2.D0*(1.D0+VR))
      ALFA=EC/ER
      BETA=VR/ER*EC
      EC3=EC22
      EKO=EC3/EC
C
      A11=(1.D0-VC23)*C2+ALFA*EKO*(1.D0+C1)+BETA*EKO*C2
      A12=VC21*C2+BETA*EKO*C1
      A21=2.D0*BETA*C1+2.D0*VC21*C2
      A22=ALFA*C1+C2
      D1=A22*VC21-A12
      D2=A11-A21*VC21
      D=A11*A22-A12*A21
      S11=(ALFA*D2+2.D0*BETA*D1)/D/EC
      E11=1.D0/S11
      S12=-(2.D0*ALFA*D1+BETA*D2)/D/EC
      V12=-S12/S11
      D3=A22*(ALFA*EKO*(1.D0-VR)-(1.D0-VC23))*C1-2.D0*A12*(BETA-VC12)*C1
      D4=2.D0*A11*(BETA-VC12)*C1-A21*(ALFA*EKO*(1.D0-VR)-(1.D0-VC23))*C1
      S2=(ALFA-BETA-(2.D0*ALFA*D3+BETA*D4)/D)/EC
      S12=-(BETA-(0.5D0*ALFA*D4+BETA*D3)/D)/EC
      S55=(GC12*C2+PARG2*(1.D0+C1))/(GC12*(1.D0+C1)+PARG2*C2)/PARG2
      G12=1.D0/S55
      A11=3.D0*(1.D0+VC23)*(1.D0/C1**2-1.D0)+4.D0*(VC23+VC12*VC21)*
     *(C1-1.D0/C1**2)+ALFA*EKO*(1.D0+VR)*(3.D0-4.D0*VR*C1+1.D0/C1**2)
      A12=2.D0*(1.D0+VC23)*(1.D0/C1-1.D0)+2.D0*(VC23+VC12*VC21)*
     *(C1-1.D0/C1)+2.D0*ALFA*EKO*(1.D0+VR)*(1.D0-VR*C1+(1.D0-VR)/C1)
      A21=3.D0*(1.D0+VC23)*(1.D0/C1**2-1.D0)+2.D0*(3.D0+VC23-
     -2.D0*VC12*VC21)*(C1-1.D0/C1**2)+ALFA*EKO*(3.D0*(1.D0+VR)-
     -2.D0*(3.D0+VR-2.D0*VR**2)*C1-(1.D0+VR)/C1**2)
      A22=2.D0*(1.D0+VC23)*(1.D0/C1-1.D0)+(3.D0+VC23-2.D0*VC12*VC21)*
     *(C1-1.D0/C1)+ALFA*EKO*(2.D0*(1.D0+VR)-(3.D0+VR-2.D0*VR**2)*C1+
     +(1.D0-VR-2.D0*VR**2)/C1)
      B1=(1.D0+VC23)-ALFA*EKO*(1.D0+VR)
      D1=B1*(A22-A12)
      D2=B1*(A11-A21)
      D=A11*A22-A12*A21
      S3=(ALFA+BETA)*(1.D0+4.D0*(1.D0-VR)*(D1+D2)/D)/EC 
      S22=(S2+S3)/2.D0
      S23=(S2-S3)/2.D0
      V23=-S23/S22
      E22=1.D0/S22
      E33=E22
      G13=G12
      V21=E22*V12/E11
      V13=V12
      G23=E22/(2.D0*(1.D0+V23))
      V31=E33*V13/E11
      V32=V23
c      WRITE(4,*)'������ ���������'
      RETURN
      END

      SUBROUTINE UKLASTORNIS         
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION VC13,VC21,VC31,VC32,GC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION ALFA,BETA,EC3,EKO,PARG2
      DOUBLE PRECISION S11,S12,S22,S23,S3,D1,D2,D,D3,D4,S2,S55
      DOUBLE PRECISION A11,A12,A21,A22,B1,S3R,S3O
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      VC13=VC12
      VC21=EC22*VC12/EC11
      VC31=VC21
      VC32=VC23
      GC23=EC22/(2.D0*(1.D0+VC23))
      PARG2=ER/(2.D0*(1.D0+VR))
      ALFA=EC/ER
      BETA=VR/ER*EC
      EC3=EC22
      EKO=EC3/EC
C
      A11=(1.D0-VC23)*C2+ALFA*EKO*(1.D0+C1)+BETA*EKO*C2
      A12=VC21*C2+BETA*EKO*C1
      A21=2.D0*BETA*C1+2.D0*VC21*C2
      A22=ALFA*C1+C2
      D1=A22*VC21-A12
      D2=A11-A21*VC21
      D=A11*A22-A12*A21
      S11=(ALFA*D2+2.D0*BETA*D1)/D/EC
      E11=1.D0/S11
      S12=-(2.D0*ALFA*D1+BETA*D2)/D/EC
      V12=-S12/S11
      D3=A22*(ALFA*EKO*(1.D0-VR)-(1.D0-VC23))*C1-2.D0*A12*(BETA-VC12)*C1
      D4=2.D0*A11*(BETA-VC12)*C1-A21*(ALFA*EKO*(1.D0-VR)-(1.D0-VC23))*C1
      S2=(ALFA-BETA-(2.D0*ALFA*D3+BETA*D4)/D)/EC
      S12=-(BETA-(0.5D0*ALFA*D4+BETA*D3)/D)/EC
      S55=(GC12*C2+PARG2*(1.D0+C1))/(GC12*(1.D0+C1)+PARG2*C2)/PARG2
      G12=1.D0/S55
      A11=3.D0*(1.D0+VC23)*(1.D0/C1**2-1.D0)+4.D0*(VC23+VC12*VC21)*
     *(C1-1.D0/C1**2)+ALFA*EKO*(1.D0+VR)*(3.D0-4.D0*VR*C1+1.D0/C1**2)
      A12=2.D0*(1.D0+VC23)*(1.D0/C1-1.D0)+2.D0*(VC23+VC12*VC21)*
     *(C1-1.D0/C1)+2.D0*ALFA*EKO*(1.D0+VR)*(1.D0-VR*C1+(1.D0-VR)/C1)
      A21=3.D0*(1.D0+VC23)*(1.D0/C1**2-1.D0)+2.D0*(3.D0+VC23-
     -2.D0*VC12*VC21)*(C1-1.D0/C1**2)+ALFA*EKO*(3.D0*(1.D0+VR)-
     -2.D0*(3.D0+VR-2.D0*VR**2)*C1-(1.D0+VR)/C1**2)
      A22=2.D0*(1.D0+VC23)*(1.D0/C1-1.D0)+(3.D0+VC23-2.D0*VC12*VC21)*
     *(C1-1.D0/C1)+ALFA*EKO*(2.D0*(1.D0+VR)-(3.D0+VR-2.D0*VR**2)*C1+
     +(1.D0-VR-2.D0*VR**2)/C1)
      B1=(1.D0+VC23)-ALFA*EKO*(1.D0+VR)
      D1=B1*(A22-A12)
      D2=B1*(A11-A21)
      D=A11*A22-A12*A21
      S3R=(ALFA+BETA)*(1.D0+4.D0*(1.D0-VR)*(D1+D2)/D)/EC 
      S3O=(ALFA+BETA)*(1.D0-4.D0*(1.D0-VR)*D1/D)/EC 
      S3=(21.D0*S3R+4.D0*S3O)/25.D0
      WRITE(4,*)'s=',s3r,s3o,s3     
      S22=(S2+S3)/2.D0
      S23=(S2-S3)/2.D0
      V23=-S23/S22
      E22=1.D0/S22
      E33=E22
      G13=G12
      V21=E22*V12/E11
      V13=V12
      G23=E22/(2.D0*(1.D0+V23))
      V31=E33*V13/E11
      V32=V23
c      WRITE(4,*)'������ ���������'
      RETURN
      END
      SUBROUTINE UKRISTENSEN           
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,SKC,SKR,SK23
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      PARG1=EC/(2.D0*(1.D0+VC))
      PARG2=ER/(2.D0*(1.D0+VR))
      SKC=EC/(3.D0*(1.D0-2.D0*VC))
      SKR=ER/(3.D0*(1.D0-2.D0*VR))
C
      E11=EC*C1+ER*C2+(4.D0*C1*C2*(VC-VR)**2*PARG2)/
     /(C2*PARG2/(SKC+PARG1/3.D0)+C1*PARG2/(SKR+PARG2/3.D0)+1.D0)
      V12=VC*C1+VR*C2+C1*C2*(VC-VR)*(PARG2/(SKR+PARG2/3.D0)-
     -PARG2/(SKC+PARG1/3.D0))/(C2*PARG2/(SKC+PARG1/3.D0)+
     +C1*PARG2/(SKR+PARG2/3.D0)+1.D0)
      SK23=SKR+PARG2/3.D0+C1/
     /(1.D0/(SKC-SKR+(PARG1-PARG2)/3.D0)+C2/(SKR+4.D0*PARG2/3.D0))
      G12=PARG2*(PARG1*(1.D0+C1)+PARG2*C2)/(PARG1*C2+PARG2*(1.D0+C1))
      G23=PARG2*(1.D0+C1/(PARG2*(PARG1-PARG2)+(SKR+7.D0*PARG2/3.D0)/
     /(2.D0*SKR+8.D0*PARG2/3.D0)))
      E22=4.D0*G23*SK23/(SK23+G23+4.D0*V12**2*SK23*G23/E11)
      E33=E22
      G13=G12
      V21=E22*V12/E11
      WRITE(4,*)' V21=',V21
      V21=4.D0*V12**2*SK23*G23/(E11*(SK23+G23)+4.D0*V12**2*SK23*G23)
      WRITE(4,*)' V21=',V21
      V13=V12
      V23=E22/(2.D0*G23)-1.D0
      WRITE(4,*)' V23=',V23
      V23=(SK23-G23-4.D0*V12**2*SK23*G23/E11)/
     /(SK23+G23+4.D0*V12**2*SK23*G23/E11)
      WRITE(4,*)' V23=',V23
      V31=E33*V13/E11
      V32=V23
      WRITE(4,*)' V12=',V12
      v12=DSQRT((-V23-E22/SK23/4.D0+E22/G23/4.D0)*E11/E22)
      WRITE(4,*)' V12=',V12
      WRITE(4,*)'������ �����������'
      RETURN
      END
      SUBROUTINE USMESI           
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,QK1 
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      PARG1=EC/(2.D0*(1.D0+VC))
      PARG2=ER/(2.D0*(1.D0+VR))
      QK1=3.D0-4.D0*VR
      E11=EC*C1+ER*C2
      E22=EC*ER/(ER*C1+EC*C2)
      E33=E22
      G12=(PARG1*PARG2/(PARG1*C2+PARG2*C1))
      G13=G12
      G23=(PARG2*(QK1+C1+C2*PARG2/PARG1)/(C2*QK1+
     +(1.D0+C1*QK1)*(PARG2/PARG1)))
      V12=VC*C1+VR*C2
      V21=E22*V12/E11
      V13=V12
      V23=E22/(2.D0*G23)-1.D0
      V31=E33*V13/E11
      V32=V23
C      WRITE(4,*)'������ ������'
c      WRITE(4,*)'E11=',E11,'E22=',E22,'E33=',E33
c      WRITE(4,*)'G12=',G12,'G13=',G13,'G23=',G23
c      WRITE(4,*)'G21=',G21,'G31=',G31,'G32=',G32
c      WRITE(4,*)'V12=',V12,'V13=',V13,'V23=',V23
c      WRITE(4,*)'V21=',V21,'V31=',V31,'V32=',V32
      RETURN
      END

      SUBROUTINE UVANIN           
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,QK1,QK2,GCR
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      PARG1=EC/(2.D0*(1.D0+VC))
      PARG2=ER/(2.D0*(1.D0+VR))
      GCR=PARG1/PARG2
      QK1=3.D0-4.D0*VR
      QK2=3.D0-4.D0*VC
      E11=EC*C1+ER*C2           
      V12=VR-GCR*C1*(QK1+1.D0)*(VR-VC)/
     /(C2*(QK2-1.D0)+GCR*(C2+1.D0+C1*QK1))
      E22=1.D0/(V12**2/E11+(QK1+1.D0)/(8.D0*PARG2)*
     *((QK2-1.D0+2.D0*GCR)/(C2*(QK2-1.D0)+GCR*(C2+1.D0+C1*QK1))-
     -2.D0*(GCR-1.D0)*C1/(C2+GCR*(C1+QK1))))
      E33=E22
      G12=(C2+GCR*(C1+1.D0))/(C1+1.D0+GCR*C2)*PARG2
      G13=G12
      G23=(C2+GCR*(C1+QK1))/(QK1*(C1+GCR*C2)+1.D0)*PARG2
      V21=V12*E22/E11
      V23=E22/(2.D0*G23)-1.D0
      V13=V12
      V31=V21
      V32=V23
      WRITE(4,*)'������ ������'
      RETURN
      END
      SUBROUTINE UVARIACIAM         
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION VC13,VC21,VC31,VC32,GC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION G23M,G23P,E22M,E22P,E33M,E33P
      DOUBLE PRECISION V23M,V23P,V21M,V21P,V31M,V31P,V32M,V32P
      DOUBLE PRECISION PARG2,SKC,SKC1,SKC2,SKC3,SKR,SM,SK 
      DOUBLE PRECISION CGAM,CBET1,CBET2,CRO,CALF 
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      VC13=VC12
      VC21=EC22*VC12/EC11
      VC31=VC21
      VC32=VC23
      GC23=EC22/(2.D0*(1.D0+VC23))
      PARG2=ER/(2.D0*(1.D0+VR))
      SKC1=EC11/(1.D0-VC12-VC13)
      SKC2=EC22/(1.D0-VC21-VC23)
      SKC3=EC22/(1.D0-VC31-VC32)
      SKC=1.D0/(1.D0/SKC1+1.D0/SKC2+1.D0/SKC3)
      SKR=ER/(3.D0*(1.D0-2.D0*VR))
      SK=(SKR*(SKC+PARG2)*C2+SKC*(SKR+PARG2)*C1)/
     /((SKC+PARG2)*C2+(SKR+PARG2)*C1)
      write(4,*)sk
C
      E11=EC*C1+ER*C2+(4.D0*C1*C2*(VC-VR)**2)/(C2/SKC+C1/SKR+1.D0/
     /PARG2)
      V12=VC*C1+VR*C2+(C1*C2*(VC-VR)*(1.D0/SKR-1.D0/SKC))/
     /(C2/SKC+C1/SKR+1.D0/PARG2)          
      G12=PARG2+C1/(1.D0/(GC12-PARG2)+VR/(2.D0*PARG2))
      G23M=PARG2+C1/(1.D0/(GC23-PARG2)+C2*(SKR+2.D0*PARG2)/
     /(2.D0*PARG2*(SKR+PARG2)))
      CGAM=GC23/PARG2
      CBET2=SKC/(SKC+2.D0*GC23)
      CBET1=SKR/(SKR+2.D0*PARG2)
      CRO=(CGAM+CBET1)/(CGAM-1.D0)
      CALF=(CBET1-CGAM*CBET2)/(CGAM*CBET2+1.D0) 
      G23P=PARG2*(1.D0+C1*(1.D0+CBET1)/(CRO-C1*(1.D0+
     +(3.D0*CBET1**2*C2**2)/(CALF*C1**3+1.D0))))
      G13=G12
      SM=1.D0+4.D0*SK*V12**2/E11
      E22M=4.D0*SK*G23M/(SK+SM*G23M)
      E22P=4.D0*SK*G23P/(SK+SM*G23P)
      E33M=E22M
      E33P=E22P
      V23M=(SK-SM*G23P)/(SK+SM*G23P)
      V23P=(SK-SM*G23M)/(SK+SM*G23M)
      V21M=V12*E22M/E11
      V21P=V12*E22P/E11
      V32M=V23M
      V32P=V23P
      V13=V12
      V31M=V21M
      V31P=V21P
      sk=e22m/(2.d0*(1.d0-v23m-2.d0*v12**2*e22m/e11))
      write(4,*)sk
      sk=e22p/(2.d0*(1.d0-v23p-2.d0*v12**2*e22p/e11))
      write(4,*)sk
      WRITE(4,*)'������������ ������-'
      WRITE(4,*)'E1=',E11
      WRITE(4,*)'E2=',E22M,E22P
      WRITE(4,*)'E3=',E33M,E33P
      WRITE(4,*)'G12=',G12,' G13=',G13
      WRITE(4,*)'G23=',G23M,G23P
      WRITE(4,*)'V12=',V12,' V13=',V13
      WRITE(4,*)'V21=',V21M,V21P
      WRITE(4,*)'V31=',V31M,V31P
      WRITE(4,*)'V23=',V23M,V23P
      WRITE(4,*)'V32=',V32M,V32P
      RETURN
      END
      SUBROUTINE UVARIACIAP         
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION VC13,VC21,VC31,VC32,GC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION G23M,G23P,E22M,E22P,E33M,E33P
      DOUBLE PRECISION V23M,V23P,V21M,V21P,V31M,V31P,V32M,V32P
      DOUBLE PRECISION PARG2,SKC,SKC1,SKC2,SKC3,SKR,SM,SK 
      DOUBLE PRECISION CGAM,CBET1,CBET2,CRO,CALF 
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      VC13=VC12
      VC21=EC22*VC12/EC11
      VC31=VC21
      VC32=VC23
      GC23=EC22/(2.D0*(1.D0+VC23))
      PARG2=ER/(2.D0*(1.D0+VR))
      SKC1=EC11/(1.D0-VC12-VC13)
      SKC2=EC22/(1.D0-VC21-VC23)
      SKC3=EC22/(1.D0-VC31-VC32)
      SKC=1.D0/(1.D0/SKC1+1.D0/SKC2+1.D0/SKC3)
      SKR=ER/(3.D0*(1.D0-2.D0*VR))
      SK=(SKR*(SKC+PARG2)*C2+SKC*(SKR+PARG2)*C1)/
     /((SKC+PARG2)*C2+(SKR+PARG2)*C1)
      write(4,*)sk
C
      E11=EC*C1+ER*C2+(4.D0*C1*C2*(VC-VR)**2)/(C2/SKC+C1/SKR+1.D0/
     /PARG2)
      V12=VC*C1+VR*C2+(C1*C2*(VC-VR)*(1.D0/SKR-1.D0/SKC))/
     /(C2/SKC+C1/SKR+1.D0/PARG2)          
      G12=PARG2+C1/(1.D0/(GC12-PARG2)+VR/(2.D0*PARG2))
      CGAM=GC23/PARG2
      CBET2=SKC/(SKC+2.D0*GC23)
      CBET1=SKR/(SKR+2.D0*PARG2)
      CRO=(CGAM+CBET1)/(CGAM-1.D0)
      CALF=(CBET1-CGAM*CBET2)/(CGAM*CBET2+1.D0) 
      G23M=PARG2*(1.D0+C1*(1.D0+CBET1)/(CRO-C1*(1.D0+
     +(3.D0*CBET1**2*C2**2)/(CALF*C1**3-CBET1))))
      G23P=PARG2+C1/(1.D0/(GC23-PARG2)+C2*(SKR+2.D0*PARG2)/
     /(2.D0*PARG2*(SKR+PARG2)))
      G13=G12
      SM=1.D0+4.D0*SK*V12**2/E11
      E22M=4.D0*SK*G23M/(SK+SM*G23M)
      E22P=4.D0*SK*G23P/(SK+SM*G23P)
      E33M=E22M
      E33P=E22P
      V23M=(SK-SM*G23P)/(SK+SM*G23P)
      V23P=(SK-SM*G23M)/(SK+SM*G23M)
      V21M=V12*E22M/E11
      V21P=V12*E22P/E11
      V32M=V23M
      V32P=V23P
      V13=V12
      V31M=V21M
      V31P=V21P
      sk=e22m/(2.d0*(1.d0-v23m-2.d0*v12**2*e22m/e11))
      write(4,*)sk
      sk=e22p/(2.d0*(1.d0-v23p-2.d0*v12**2*e22p/e11))
      write(4,*)sk
      WRITE(4,*)'������������ ������-'
      WRITE(4,*)'E1=',E11
      WRITE(4,*)'E2=',E22M,E22P
      WRITE(4,*)'E3=',E33M,E33P
      WRITE(4,*)'G12=',G12,' G13=',G13
      WRITE(4,*)'G23=',G23M,G23P
      WRITE(4,*)'V12=',V12,' V13=',V13
      WRITE(4,*)'V21=',V21M,V21P
      WRITE(4,*)'V31=',V31M,V31P
      WRITE(4,*)'V23=',V23M,V23P
      WRITE(4,*)'V32=',V32M,V32P
      RETURN
      END
      SUBROUTINE SHAPEL           
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,SKC,SKR,PARG,SK
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      PARG1=EC/(2.D0*(1.D0+VC))
      PARG2=ER/(2.D0*(1.D0+VR))
      SKC=EC/(3.D0*(1.D0-2.D0*VC))
      SKR=ER/(3.D0*(1.D0-2.D0*VR))
C
      PARG=PARG2*(1.D0-15.D0*(1.D0-VR)*(1.D0-PARG1/PARG2)*C1/
     /(7.D0-5.D0*VR+2.D0*(4.D0-5*VR)*(PARG1/PARG2)))
      SK=SKR+(SKC-SKR)*C1/(1.D0+((SKC-SKR)/(SKR+4.D0*PARG2/3.D0)))
      E11=9.D0*SK/(1.D0+3.D0*SK/PARG)
      V12=(1.D0-2.D0*PARG/(3.D0*SK))/(2.D0+2.D0*PARG/(3.D0*SK))
      G12=PARG
      G23=PARG
      E22=E11
      E33=E22
      G13=G12
      V21=E22*V12/E11
      V13=V12
      V23=E22/(2.D0*G23)-1.D0
      V31=E33*V13/E11
      V32=V23
      WRITE(4,*)'����?� ��?�������� (���� ���� ��������� ��������)'
      WRITE(4,*)'E=',E11,'V=',V12
      WRITE(4,*)'KR=',SKR,'NR=',PARG2
      WRITE(4,*)'KC=',SKC,'NC=',PARG1
      WRITE(4,*)'K=',SK,'N=',PARG
      RETURN
      END
      SUBROUTINE SHAPEB           
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,SKC,SKR,PARG,SK
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      PARG1=EC/(2.D0*(1.D0+VC))
      PARG2=ER/(2.D0*(1.D0+VR))
      SKC=EC/(3.D0*(1.D0-2.D0*VC))
      SKR=ER/(3.D0*(1.D0-2.D0*VR))
C
      PARG=PARG1*(1.D0-(1.D0-PARG2/PARG1)*(1.D0-C1)*
     *(7.D0-5.D0*VR+2.D0*(4.D0-5.D0*VR)*(PARG1/PARG2))/
     /(15.D0*(1.D0-VR)))
      SK=SKR+(SKC-SKR)*C1/(1.D0+(1.D0-C1)*((SKC-SKR)/
     /(SKR+4.D0*PARG2/3.D0)))
      E11=9.D0*SK/(1.D0+3.D0*SK/PARG)
      V12=(1.D0-2.D0*PARG/(3.D0*SK))/(2.D0+2.D0*PARG/(3.D0*SK))
      G12=PARG
      G23=PARG
      E22=E11
      E33=E22
      G13=G12
      V21=E22*V12/E11
      V13=V12
      V23=E22/(2.D0*G23)-1.D0
      V31=E33*V13/E11
      V32=V23
      WRITE(4,*)'����?� ��?�������� (������ ���� ��������� ��������)'
      WRITE(4,*)'E=',E11,'V=',V12
      WRITE(4,*)'KR=',SKR,'NR=',PARG2
      WRITE(4,*)'KC=',SKC,'NC=',PARG1
      WRITE(4,*)'K=',SK,'N=',PARG
      RETURN
      END
      SUBROUTINE ELIPSKARPINOS           
C     ***************************************************
C     �?��������� ��� ���������� ������� ������ ���������
C     ***************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,SKC,SKR,PARG,SK,PARGD
      DOUBLE PRECISION SK3,EN,EM,EL,ELAM1,EL1,EM1,EN1
      DOUBLE PRECISION EA,EB,A1,B1,HE,EJ1,EJ2,EJ3,DELT,Z1
      DOUBLE PRECISION Z3,Z4,PE,EK,PARGS,PARG3,DELT1,DELT2
      DOUBLE PRECISION Z2,Z5,EQ
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      PARG1=EC/(2.D0*(1.D0+VC))
      PARG2=ER/(2.D0*(1.D0+VR))
      SKC=EC/(3.D0*(1.D0-2.D0*VC))
      SKR=ER/(3.D0*(1.D0-2.D0*VR))
C 
      SK=C1*SKC+C2*SKR
      SK3=SKC-SKR
      EN=(SKC*SKR)/(C1*SKR+C2*SKC)   
      EM=(VC*VR)/(C1*VR+C2*VC)
      EL=EN-2.D0/3.D0*EM
      ELAM1=SKC-2.D0/3.D0*VC
      EL1=ELAM1-EL
      EM1=VC-EM
      EN1=SKC-EN
      EA=EL+EM   
      EB=EL+2.D0*EM
      A1=EL1+EM1
      B1=EL1+2.D0*EM1
      HE=-EK/(DSQRT(EK**2-1.D0))*DLOG(EK-DSQRT(EK**2-1.D0))
      EJ1=(1.D0-HE)/(1.D0-EK**2)
      EJ2=1.D0-EJ1
      EJ3=(0.5D0*(1.D0-EK**2)**2)*((1.D0-EK**2)*HE-3.D0*EK**2) 
      DELT=EM*EB*(EM+ELAM1+VC+EM1*EJ1)+3.D0*EM1*(EA*(EB+EN1)*EJ3+
     +EM*EN1*EJ1*EJ2)
      Z1=(1.D0/DELT)*(EL1*EM*EJ1*EJ2+EA*(ELAM1+2.D0*EM)*EJ3)
      Z3=-1.D0/(2*DELT)*((ELAM1+2.D0*PARG1)*EA*EJ3+
     +EM*(EB*EJ2+B1*EJ1*EJ2))
      Z4=(1.D0/DELT)*(EM*A1*EJ1**2-(ELAM1+VC+EM)*(EA*EJ3+EM*EJ1))
      PE=2.D0*(Z1+Z3)+Z4  
      EK=SK+(C1*C2*(SK3**2)*PE)/(1.D0+C1*SK3*PE)
      PARGS=C1*PARG1+C2*PARG2
      PARG3=PARG1-PARG2
      DELT1=(2.D0*EB*EM)/(EA*EJ3+EB*EJ2)
      DELT2=(2.D0*EB*EM)/(EB*(1.D0+EJ1)-4.D0*EA*EJ3)
      Z2=-1.D0/(EM1+DELT1)
      Z5=-1.D0/(EM1+DELT2)
      EQ=2.D0/15.D0*(Z3-2.D0*(Z1-Z4)+3.D0*(Z2+Z5))
      PARG=PARGS+(C1*C2*PARG3**2*EQ)/(1.D0+C1*PARG3*EQ)
C 
C      PARGD=PARG1*(9.D0*SKC+8.D0*PARG1)/(6.D0*(SKC+2.D0*PARG1))
C      PARG=PARG2+(PARG1-PARG2)*C1/
C     /(1.D0+(PARG1-PARG2)/(PARG2+PARGD))
C      SK=SKR+(SKC-SKR)*C1/(1.D0+(SKC-SKR)/
C     /(SKR+4.D0*PARG1/3.D0))
      E11=9.D0*SK/(1.D0+3.D0*SK/PARG)
      V12=(1.D0-2.D0*PARG/(3.D0*SK))/(2.D0+2.D0*PARG/(3.D0*SK))
      G12=PARG
      G23=PARG
      E22=E11
      E33=E22
      G13=G12
      V21=E22*V12/E11
      V13=V12
      V23=E22/(2.D0*G23)-1.D0
      V31=E33*V13/E11
      V32=V23
      WRITE(4,*)'����?� ��?�������� (����������? ��?�����? ���������)'
      WRITE(4,*)'E=',E11,'PARG=',PARG
C      WRITE(4,*)'E=',E11,'V=',V12
C      WRITE(4,*)'KR=',SKR,'NR=',PARG2
C      WRITE(4,*)'KC=',SKC,'NC=',PARG1
C      WRITE(4,*)'K=',SK,'N=',PARG
      RETURN
      END
      SUBROUTINE ELIPS           
C     ********************************************************
C     ������������ ��� ���������� ������� ���������� ���������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,SKC,SKR,PARG,SK,PARGD
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      PARG1=EC/(2.D0*(1.D0+VC))
      PARG2=ER/(2.D0*(1.D0+VR))
      SKC=EC/(3.D0*(1.D0-2.D0*VC))
      SKR=ER/(3.D0*(1.D0-2.D0*VR))
C
      PARGD=PARG1*(9.D0*SKC+8.D0*PARG1)/(6.D0*(SKC+2.D0*PARG1))
      PARG=PARG2+(PARG1-PARG2)*C1/
     /(1.D0+(PARG1-PARG2)/(PARG2+PARGD))
      SK=SKR+(SKC-SKR)*C1/(1.D0+(SKC-SKR)/
     /(SKR+4.D0*PARG1/3.D0))
      E11=9.D0*SK/(1.D0+3.D0*SK/PARG)
      V12=(1.D0-2.D0*PARG/(3.D0*SK))/(2.D0+2.D0*PARG/(3.D0*SK))
      G12=PARG
      G23=PARG
      E22=E11
      E33=E22
      G13=G12
      V21=E22*V12/E11
      V13=V12
      V23=E22/(2.D0*G23)-1.D0
      V31=E33*V13/E11
      V32=V23
      WRITE(4,*)'����?� ��?�������� (����������? ��?�����? ���������)'
      WRITE(4,*)'E=',E11,'V=',V12
      WRITE(4,*)'KR=',SKR,'NR=',PARG2
      WRITE(4,*)'KC=',SKC,'NC=',PARG1
      WRITE(4,*)'K=',SK,'N=',PARG
      RETURN
      END
      SUBROUTINE UKARPINOS           
C     ********************************************************
C     �������� ��� ��������� ����� ������� ��������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23
      DOUBLE PRECISION C1,C2,CQ
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,QK1,QK2,EN,EQ 
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/CONPOR/CQ            
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ��������� ��������� 
C      WRITE(4,*)'C1=',C1
      C2=1.D0-C1
      EC=EC11
      VC=VC12
      ER=ER11
      VR=VR12
      PARG1=EC/(2.D0*(1.D0+VC))
      PARG2=ER/(2.D0*(1.D0+VR))
      QK1=3.D0-4.D0*VR
      QK2=3.D0-4.D0*VC
      E11=EC*C1*(1-CQ**2)+ER*C2
      V12=VR+C1*(VC-VR)*(QK1+1.D0)*(1.D0-CQ**2)/
     /((1.D0-CQ**2)*(1.D0+C2+C1*QK1)+C2*(QK2-1.D0+2.D0*CQ**2)*
     *PARG2/PARG1)
      V13=V12
      EQ=C1*(1.D0-CQ**2-(1.D0+QK2*CQ**2)*PARG2/PARG1)/
     /((1.D0-CQ**2)*QK1+(1.D0+QK2*CQ**2)*PARG2/PARG1)
      EN=C2+C1*(QK1+1.D0)*(1.D0-CQ**2)/
     /(2.D0*(1.D0-CQ**2)+(QK2-1.D0+2.D0*CQ**2)*PARG2/PARG1)
      EL=1.D0/(-C2+(QK1+1.D0)*(1.D0-CQ**2)/
     /(1.D0-CQ**2-(1.D0+QK2*CQ**2)*PARG2/PARG1))
      E22=1.D0/(V12**2/E11+(QK1+1.D0)/(8.D0*PARG2)*
     *(1.D0/EN-2.D0*EQ/(1.D0+EQ)))
      E33=E22
      V32=E22*(-V12**2/E11+VR/(2.D0*PARG2)+(QK1+1.D0)/(8.D0*PARG2)*
     *((EN-1.D0)/EN-2.D0*EQ/(1.D0+EQ)))
      G12=PARG2*(((1.D0+C1)*(1.D0-CQ**2)+C2*(1.D0+CQ**2)*PARG2/PARG1)/
     /(C2*(1.D0-CQ**2)+(1.D0+C1)*(1.D0+CQ**2)*PARG2/PARG1))
      G13=G12
      G23=PARG2/(1.D0-C1*(QK1+1.D0)*EL)
      V21=E22*V12/E11
      V31=E33*V13/E11
      V23=V32
c      WRITE(4,*)'����� ������ (���� ������)'
c      WRITE(4,*)'E11=',E11,'E22=',E22,'E33=',E33
c      WRITE(4,*)'G12=',G12,'G13=',G13,'G23=',G23
C      WRITE(4,*)'G21=',G21,'G31=',G31,'G32=',G32
c      WRITE(4,*)'V12=',V12,'V13=',V13,'V23=',V23
c      WRITE(4,*)'V21=',V21,'V31=',V31,'V32=',V32
c      STOP
      RETURN
      END
      SUBROUTINE USTOLYAROVA           
C     ********************************************************
C     �������� ��� ��������� ����� ������� ��������
C     ********************************************************
      DOUBLE PRECISION DC,HA,ICO,ALFA,BET,GAMME,DV,DR
      DOUBLE PRECISION EC11,EC22,GC12,VC12,VC23,VC21
      DOUBLE PRECISION ER11,ER22,GR12,VR12,VR23,VR21
      DOUBLE PRECISION C1,C2,CQ
      DOUBLE PRECISION E11,E22,E33,G23,G12,G13
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      DOUBLE PRECISION PARG1,PARG2,QK1,QK2,EN,EQ 
      DOUBLE PRECISION PI
      COMMON/ARMIR/DC,HA,ICO
      COMMON/UKVO/EC11,EC22,GC12,VC12,VC23
      COMMON/UKMA/ER11,ER22,GR12,VR12,VR23
      COMMON/CONCEN/C1,C2      
      COMMON/CONPOR/CQ            
      COMMON/KAMOD/E11,E22,E33,G23,G12,G13
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      PI=4.D0*DATAN(1.D0)
C     ��������� ��������� 
C      WRITE(4,*)'C1=',C1
      VR21=VR12*ER22/ER11
      VC21=VC12*EC22/EC11
      C2=1.D0-C1
      ALFA=(1.D0-C1-CQ)*((ER22*VC23-EC22*VR23)*C1-ER22*(C1-2.D0*CQ))-
     -EC22*(1.D0+C1+CQ)*C1
      BET=2.D0*(C1+CQ)*(VC21*ER22*(1-C1-CQ)+VR21*EC22*C1)
      GAMME=2.D0*C1*(C1+CQ)*(VC21*ER22*VR12/ER11-VR21*EC22*VR12/EC11)
CC      WRITE(4,*) 'ALFA=',ALFA 
CC      WRITE(4,*) 'BET=',BET 
CC      WRITE(4,*) 'GAMME=',GAMME 
      DV=(ALFA+BET*VC12)/(ALFA*EC11)
      DR=(ALFA+BET*VR12)/(ALFA*ER11)
CC      WRITE(4,*) 'DV=',DV 
CC      WRITE(4,*) 'DR=',DR 
c
      Q11=4.D0*(C1+CQ)**3*(VR23+VR21*VR12)-
     *(1.D0+VR23)*(1.D0+3.D0*(C1+CQ)**2)
CC      WRITE(4,*) 'Q11=',Q11 
      Q12=4.D0*(C1+CQ)*(1.D0-VR21*VR12)+
     *(1.D0+VR23)*((C1+CQ)**2-1.D0)
CC      WRITE(4,*) 'Q12=',Q12 
      Q13=(3.D0*CQ*(C1+CQ)**2+CQ**3)*(1.D0+VC23)-
     *4.D0*(C1+CQ)**3*(VC23+VC21*VC12)
CC      WRITE(4,*) 'Q13=',Q13 
      Q14=((C1+CQ)**2-CQ**2)*(1.D0+VC23)+
     *4.D0*CQ*(C1+CQ)*(1.D0-VC21*VC12)
CC      WRITE(4,*) 'Q14=',Q14 
      Q21=2.D0*(C1+CQ)**3*(3.D0+VR23-2.D0*VR21*VR12)+
     *(1.D0+VR23)*(1.D0-3.D0*(C1+CQ)**2)
CC      WRITE(4,*) 'Q21=',Q21 
      Q22=2.D0*(C1+CQ)*(VR23+2.D0*VR21*VR12-1.D0)-
     *(1.D0+VR23)*((C1+CQ)**2+1.D0)
CC      WRITE(4,*) 'Q22=',Q22 
      Q23=(3.D0*CQ*(C1+CQ)**2-CQ**3)*(1.D0+VC23)-
     *2.D0*(C1+CQ)**3*(3.D0+VC23-2.D0*VC21*VC12)
CC      WRITE(4,*) 'Q23=',Q23 
      Q24=((C1+CQ)**2+CQ**2)*(1.D0+VC23)-
     *2.D0*CQ*(C1+CQ)*(VC23+2.D0*VC21*VC12-1.D0)
CC      WRITE(4,*) 'Q24=',Q24 
      D11=Q11*(C1**2+3.D0*(C1+CQ)*(CQ-1.D0))-
     *3.D0*Q12*(C1+CQ)*(CQ-1.D0)*(C1+2.D0*CQ+1.D0)
CC      WRITE(4,*) 'D11=',D11 
      D12=Q13*((C1+CQ)**2+(C1+CQ)*(1.D0-3.D0*CQ)+1.D0)-
     *3.D0*Q14*(C1+CQ)*(CQ-1.D0)*(C1+2.D0*CQ+1.D0)
CC      WRITE(4,*) 'D12=',D12 
      D13=Q13*ER22*(C1+CQ-1.D0)*((C1+CQ)**2+C1+CQ+1.D0)+
     *EC22*C1*(Q11*(C1**2+3.D0*CQ*(C1+CQ))-3.D0*(1.D0+VR23)*
     *(C1+CQ)**2*(C1+CQ-1.D0)*(CQ-1.D0)*(C1+2.D0*CQ+1.D0))
CC      WRITE(4,*) 'D13=',D13 
      D21=Q21*(C1**2+3.D0*(C1+CQ)*(CQ-1.D0))+
     *3.D0*Q22*(C1+CQ)*(CQ-1.D0)*(C1+2.D0*CQ+1.D0)
CC      WRITE(4,*) 'D21=',D21 
      D22=Q23*((C1+CQ)**2+(C1+CQ)*(1.D0-3.D0*CQ)+1.D0)-
     *3.D0*Q24*(C1+CQ)*(CQ-1.D0)*(C1+2.D0*CQ+1.D0)
CC      WRITE(4,*) 'D22=',D22 
      D23=Q23*ER22*(C1+CQ-1.D0)*((C1+CQ)**2+C1+CQ+1.D0)+
     *EC22*C1*(Q21*(C1**2+3.D0*CQ*(C1+CQ))-3.D0*(1.D0+VR23)*
     *(C1+CQ)**2*(C1+CQ-1.D0)*(CQ-1.D0)*(C1+2.D0*CQ+1.D0))
CC      WRITE(4,*) 'D23=',D23 
      T1=D21*EC22*C1+Q23*ER22*(C1+CQ-1.D0)**3
CC      WRITE(4,*) 'T1=',T1 
      T2=D11*EC22*C1+Q13*ER22*(C1+CQ-1.D0)**3
CC      WRITE(4,*) 'T2=',T2 
      T3=Q11*EC22*C1**3+D12*ER22*(C1+CQ-1.D0)
CC      WRITE(4,*) 'T3=',T3 
      T4=Q21*EC22*C1**3+D22*ER22*(C1+CQ-1.D0)
CC      WRITE(4,*) 'T4=',T4 
      PSI1=D13*T4-D23*T3
CC      WRITE(4,*) 'PSI1=',PSI1 
      PSI2=D23*T2-D13*T1
CC      WRITE(4,*) 'PSI2=',PSI2  
      PSI3=T1*T3-T2*T4
CC      WRITE(4,*) 'PSI3=',PSI3 
      QA=ER22*(2.D0*CQ+C1*(1.D0-VC23))*(C1+CQ-1.D0)-
     *C1*EC22*((C1+CQ)*(1.D0-VR23)+(1.D0+VR23))
CC      WRITE(4,*) 'QA=',QA 
      TAU=ER22*(1.D0+VC23)*(C1+CQ-1.D0)+
     *EC22*((C1+CQ)*(1.D0-VR23)+(1.D0+VR23))
CC      WRITE(4,*) 'TAU=',TAU 
      DR0=VR21/ER22*(VC21*(TAU/QA*C1+1.D0)-2.D0*VR21/(1.D0-VR23)-
     *2.D0*VR21*EC22*C1*(C1+CQ)/QA)-(1.D0-VR23-2.D0*VR21*VR12)/
     *(ER11*(1.D0-VR23))
CC      WRITE(4,*) 'DR0=',DR0 
      DV0=VC21/EC22*(VC21*(TAU/QA*C1+1.D0)-2.D0*VC21/(1.D0-VC23)-
     *2.D0*VR21*EC22*C1*(C1+CQ)/QA)-(1.D0-VC23-2.D0*VC21*VC12)/
     *(EC11*(1.D0-VC23))
CC      WRITE(4,*) 'DV0=',DV0 
      D0=(VC21*TAU/EC22/QA-2.D0*VR21*(C1+CQ)/QA)*(EC22/ER22*C1*
     *(1.D0-VR23)-C1*(1.D0-VC23)-2.D0*CQ)-2.D0*VR21/ER22+
     *VC21/EC22*(1.D0+VC23)+VC21/ER22*(1.D0-VR23)
CC      WRITE(4,*) 'D0=',D0 
      GAM1=(1.D0-VR23)-D0*C1*VR21/(DR0*C1+DV0*(1.D0-C1-CQ))
CC      WRITE(4,*) 'GAM1=',GAM1 
      GAM2=(1.D0-VC23)-D0*(C1+CQ-1.D0)*VC21/(DR0*C1+DV0*(1.D0-C1-CQ))
CC      WRITE(4,*) 'GAM2=',GAM2 
      GAM3=(((C1+CQ)*(3.D0*CQ*(C1+2.D0*CQ)-2.D0*(C1+3.D0))-C1*CQ)*PSI1+
     +C1**2*PSI2+((C1+CQ)**2+CQ*(C1+2.D0*CQ))*PSI3)/(3.D0*PSI3*
     *(CQ-1.D0)*(C1+2.D0*CQ+1.D0)*(C1+CQ-1.D0))
CC      WRITE(4,*) 'GAM3=',GAM3 
      GAM4=(((CQ-1.D0)*(4.D0*(C1+CQ)**2+CQ*(C1+2.D0*CQ))-C1**2*CQ)*PSI1-
     -C1**2*PSI2-((C1+CQ)**2+CQ*(C1+2.D0*CQ))*PSI3)/(3.D0*PSI3*
     *(CQ-1.D0)*(C1+2.D0*CQ+1.D0)*(C1+CQ-1.D0))
CC      WRITE(4,*) 'GAM4=',GAM4 
      E22=2.D0*QA*ER22/(QA*(4.D0*GAM3*(1.D0-VR21*VR12)+(1.D0+VR23)+
     +GAM1)+2.D0*(C1+CQ)*(C1*GAM1*EC22-ER22*((C1+2.D0*CQ)*GAM2+
     +2.D0*CQ*VC23)))
CC      WRITE(4,*)'E22=',E22
      E22=2.D0*QA*ER22/(QA*(4.D0*GAM4*(1.D0-VR21*VR12)+(1.D0+VR23)+
     +GAM1)+2.D0*(C1+CQ)*(C1*GAM1*EC22-ER22*((C1+2.D0*CQ)*GAM2+
     +2.D0*CQ*VC23)))
      V23=(QA*(4.D0*GAM3*(1.D0-VR21*VR12)+(1.D0+VR23)-
     -GAM1)-2.D0*(C1+CQ)*(C1*GAM1*EC22-ER22*((C1+2.D0*CQ)*GAM2+
     +2.D0*CQ*VC23)))/(QA*(4.D0*GAM3*(1.D0-VR21*VR12)+(1.D0+VR23)+
     +GAM1)+2.D0*(C1+CQ)*(C1*GAM1*EC22-ER22*((C1+2.D0*CQ)*GAM2+
     +2.D0*CQ*VC23)))
CC      WRITE(4,*)'V23=',V23
      V23=(QA*(4.D0*GAM4*(1.D0-VR21*VR12)+(1.D0+VR23)-
     -GAM1)-2.D0*(C1+CQ)*(C1*GAM1*EC22-ER22*((C1+2.D0*CQ)*GAM2+
     +2.D0*CQ*VC23)))/(QA*(4.D0*GAM4*(1.D0-VR21*VR12)+(1.D0+VR23)+
     +GAM1)+2.D0*(C1+CQ)*(C1*GAM1*EC22-ER22*((C1+2.D0*CQ)*GAM2+
     +2.D0*CQ*VC23)))
C
C
c
      E11=ER11*ALFA*(DR*C1+DV*(1.D0-C1-CQ))/(DV*ALFA-GAMME)
      V12=(VR21*VR12*DV*ALFA-GAMME)/(VR21*(DV*ALFA-GAMME))
      V13=V12

CC      E22=V12**2/E11+(QK1+1.D0)/(8.D0*PARG2)*(1.D0/EN-2.D0*EQ/(1.D0+EQ))
CC      E33=E22
CC      V32=E22*(-V12**2/E11+VR/(2.D0*PARG2)+(QK1+1.D0)/(8.D0*PARG2)*
CC     *((EN-1.D0)/EN-2.D0*EQ/(1.D0+EQ)))
C
      G12=GR12*(GC12*C1*(1.D0+C1+CQ)**2+GR12*(C1+2.D0*CQ)*
     *(1.D0-(C1+CQ)**2))/(GR12*(C1+2.D0*CQ)*(1.D0+C1+CQ)**2+
     +GC12*C1*(1.D0-(C1+CQ)**2))
      G13=G12
      E33=E22
      V21=E22*V12/E11
      V31=E33*V13/E11
      V32=V23
      G23=E22/(2.D0*(1.D0+V23))
CC      V21=E22*V12/E11
CC      V31=E33*V13/E11
CC      V23=V32
C      WRITE(4,*)'����� ��������'
C      WRITE(4,*)'E11=',E11,'E22=',E22,'E33=',E33
C      WRITE(4,*)'G12=',G12,'G13=',G13,'G23=',G23
C      WRITE(4,*)'V12=',V12,'V13=',V13,'V23=',V23
C      WRITE(4,*)'V21=',V21,'V31=',V31,'V32=',V32
C      STOP
      RETURN
      END







