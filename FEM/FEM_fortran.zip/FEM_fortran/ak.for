      SUBROUTINE AKOFM3(RMN,MAT,MN,MNL,AL,
     ,W,XE,VT,BT,V,EPO,SIO,MNL3)
C
C     ����������� ������� ��������� ��� �������� �����
C     �� ���� ������ �� ������������ ���������.
C
      DOUBLE PRECISION EPO,SIO,GK,GN,CK,CN,CNT,SIG,FI,S,F,FII,
     ,STT,W,AL,XE,VT,V,P,ET,ST,BT,GKDOP,PDOP,CSI,AS,DET,CORECT,O1,O2,O3,
     ,Q1,Q2,Q3,AQ,T,FUN,FUN2,FUN3,AT,ALFAT,AGP,RMNLI,CK0
      DOUBLE PRECISION RMN
      COMMON/KKTI/KT1,KT2,KT3
      COMMON/ACSI/CSI(3,10),AS(3,10)
      COMMON/DET/DET
      COMMON/KSO/MM,NN,LL,L,LO1(4)
      COMMON/MSKE/MSKE
      COMMON/CORECT/CORECT
      COMMON/MNLMCX/MNLX,MCX
      DIMENSION EPO(6,MNL3),SIO(6,MNL3),CK0(3,3),
     ,GK(3,3),GN(3,3),CK(3,3),CN(3,3),CNT(3,3),
     ,SIG(3,3),FI(3,3),S(6),F(6),FII(3,3),STT(6),
     ,W(1),AL(1),XE(1),VT(1),V(1),P(3),ET(9),ST(9),BT(1)
      DIMENSION GKDOP(3,3),PDOP(3,3)
      DIMENSION RMN(911)
      DATA ET,GK,GKDOP,PDOP,FI/45*0.D0/
      DO 1001 I=1,MAT
 1001 RMN(I)=0.D0
      DO 1002 I=1,MNL3
 1002 V(I)=0.D0
      CALL COOR(XE,AL,0.D0,0.D0,0.D0)
      CALL WPRO(W(1),MNL,XE(1),AL)
      CALL WPRO(W(MNL+1),MNL,XE(MNL+1),AL)
      CALL WPRO(W(2*MNL+1),MNL,XE(2*MNL+1),AL)
      CALL WPRO(VT,MNL,BT,AL)
      CALL CKPRO(CK0,MN,MNL,W,0.D0,0.D0,0.D0)
      CALL GKN(GK,GN,CK0)
      DO 10 I1=1,3
      DO 10 J1=1,3
   10 CK0(I1,J1)=CK0(I1,J1)/DSQRT(GK(J1,J1))
      DO 1 I=1,KT1
      O1=CSI(1,I)
      Q1=AS(1,I)
      DO 1 J=1,KT2
      O2=CSI(2,J)
      Q2=AS(2,J)
      DO 1 K=1,KT3
      O3=CSI(3,K)
      Q3=AS(3,K)
      IF(MCX.LT.11)CALL CKPRO(CK,MN,MNL,W,O1,O2,O3)
      IF(MCX.EQ.11)CALL CKPR2S(CK,MN,MNL,W,O1,O2,O3)
      IF(MCX.EQ.12)CALL CKPR3S(CK,MN,MNL,W,O1,O2,O3)
      CALL OBRM33(CK,CN)
      CALL TRAN33(CN,CNT)
      CALL GKN(GK,GN,CK)
      IF(MSKE.NE.2)GOTO 141
      IF(MCX.LT.11)CALL DEFCUO(GKDOP,W,W,MNL,O1,O2,O3)
      IF(MCX.EQ.11)CALL DEFC2S(GKDOP,W,W,MNL,O1,O2,O3)
      IF(MCX.EQ.12)CALL DEFC3S(GKDOP,W,W,MNL,O1,O2,O3)
      GKDOP(2,1)=GKDOP(1,2)
      GKDOP(3,1)=GKDOP(1,3)
      GKDOP(3,2)=GKDOP(2,3)
      DO 2000 ICK=1,3
      DO 2000 JCK=1,3
 2000 GK(ICK,JCK)=GKDOP(ICK,JCK)+(GK(ICK,JCK)-GKDOP(ICK,JCK))*CORECT
      CALL OBRM33(GK,GN)
  141 CONTINUE
      CALL GKN(GK,GN,CK)
      AQ=Q1*Q2*Q3*DSQRT(DET)
      MK=0
      IF(MCX.LT.11)T=FUN(VT,O1,O2,O3)
      IF(MCX.EQ.11)T=FUN2(VT,O1,O2,O3)
      IF(MCX.EQ.12)T=FUN3(VT,O1,O2,O3)
      AT=ALFAT(T)*T
      ET(1)=AT
      ET(5)=AT
      ET(9)=AT
      CALL SIGMATERM(ET,ST,CK0,T)
      STT(1)=ST(1)
      STT(2)=ST(4)
      STT(3)=ST(7)
      STT(4)=ST(5)
      STT(5)=ST(8)
      STT(6)=ST(9)
      DO 2 II=1,MNL
      ITEK=MNL*(II-1)+1
      IF(MCX.LT.11)CALL PRFMK(P,MN,AL(ITEK),O1,O2,O3)
      IF(MCX.EQ.11)CALL PRFM2S(P,MN,AL(ITEK),O1,O2,O3)
      IF(MCX.EQ.12)CALL PRFM3S(P,MN,AL(ITEK),O1,O2,O3)
      DO 2 JJ=1,3
      JRR=MNL*(JJ-1)+1
      CALL DEFOR1(FI,CK,P,JJ)
      IF(MSKE.NE.2)GOTO 23
      IF(MCX.LT.11)CALL DEFCUE(PDOP,W(JRR),AL(ITEK),O1,O2,O3)
      IF(MCX.EQ.11)CALL DEFCU2(PDOP,W(JRR),AL(ITEK),O1,O2,O3)
      IF(MCX.EQ.12)CALL DEFCU3(PDOP,W(JRR),AL(ITEK),O1,O2,O3)
      DO 3000 ICK=1,3
      DO 3000 JCK=1,3
 3000 FI(ICK,JCK)=PDOP(ICK,JCK)+(FI(ICK,JCK)-PDOP(ICK,JCK))*CORECT
   23 CONTINUE
      FI(2,1)=FI(1,2)
      FI(3,1)=FI(1,3)
      FI(3,2)=FI(2,3)
      CALL SIGDEK(FI,FII,CNT)
c      WRITE(4,*)'FII ARM PERED SIGMA3',fii
      CALL TRAN33(FII,FI)
      CALL SIGARM(FII,CK0)
c      WRITE(4,*)'FII ARM PERED SIGMA3',fii
      CALL SIGMA3(FII,SIG,CK0,T)
c      WRITE(4,*)'FII ARM POSLE SIGMA3',sig
c      STOP
      IJ=(II-1)*3+JJ
      EPO(1,IJ)=FI(1,1)
      EPO(2,IJ)=FI(1,2)
      EPO(3,IJ)=FI(1,3)
      EPO(4,IJ)=FI(2,2)
      EPO(5,IJ)=FI(2,3)
      EPO(6,IJ)=FI(3,3)
      F(1)=FI(1,1)
      F(2)=FI(1,2)
      F(3)=FI(1,3)
      F(4)=FI(2,2)
      F(5)=FI(2,3)
      F(6)=FI(3,3)
      AGP=RMNLI(F,STT)*AQ
      IJJ=MNL*(JJ-1)+II
      V(IJJ)=V(IJJ)+AGP
      SIO(1,IJ)=SIG(1,1)
      SIO(2,IJ)=SIG(1,2)
      SIO(3,IJ)=SIG(1,3)
      SIO(4,IJ)=SIG(2,2)
      SIO(5,IJ)=SIG(2,3)
      SIO(6,IJ)=SIG(3,3)
    2 CONTINUE
      DO 200 M=1,MNL3
      F(1)=EPO(1,M)
      F(2)=EPO(2,M)
      F(3)=EPO(3,M)
      F(4)=EPO(4,M)
      F(5)=EPO(5,M)
      F(6)=EPO(6,M)
      DO 200 N=M,MNL3
      S(1)=SIO(1,N)
      S(2)=SIO(2,N)
      S(3)=SIO(3,N)
      S(4)=SIO(4,N)
      S(5)=SIO(5,N)
      S(6)=SIO(6,N)
      MK=MK+1
      AGP=RMNLI(F,S)*AQ
  200 RMN(MK)=RMN(MK)+AGP
    1 CONTINUE
c      WRITE(4,*) 'RMN=',RMN(1)
      RETURN
      END