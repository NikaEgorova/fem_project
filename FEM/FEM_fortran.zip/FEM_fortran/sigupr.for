      SUBROUTINE SIGMA3(ED,S,CK0,T)
C     **************************************************************
C     ������������ ��� ���������� ���������� � ����������� ���������
C     **************************************************************
      DOUBLE PRECISION S,V,G,DETER,DD,T,E,SS
      DOUBLE PRECISION A11,A12,A13,A22,A21,A31,A32,A23,A33
      DOUBLE PRECISION APOV,DET,SI,ED,CK0,PI
      DOUBLE PRECISION E11,E22,E33,V31,V32,V21,V13,V12,V23,G23,G21,G31
      DOUBLE PRECISION ALFA,BETA
      DIMENSION S(3,3),V(3,3),G(3,3),ED(3,3)
      DIMENSION E(3,3),APOV(3,3),CK0(3,3),SI(3,3)
      COMMON/DET/DET
      COMMON/KAMOD/E11,E22,E33,G23,G21,G31
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      DATA APOV/9*0.D0/
      PI=4.D0*DATAN(1.D0)
C     ����������� ���������� 
      CALL UPRUCOM
C     ������ ��������� I � II ���� ������������ ������������ 
C     ���������
      E(1,1)=E11 
      E(2,2)=E22
      E(3,3)=E33       
      G(3,1)=G31
      G(2,1)=G21
      G(2,3)=G23       
C     ����������� �������� 
      V(2,3)=V23
      V(3,2)=V32 
      V(1,2)=V12 
      V(2,1)=V21 
      V(1,3)=V13
      V(3,1)=V31
C     �������� ���������
      G(1,2)=G(2,1)
      G(1,3)=G(3,1)
      G(3,2)=G(2,3)
c      WRITE(4,*)'E11=',E11,'E22=',E22,'E33=',E33
c      WRITE(4,*)'G12=',G(1,2),'G13=',G(1,3),'G23=',G(2,3)
c      WRITE(4,*)'G21=',G(2,1),'G31=',G(3,1),'G32=',G(3,2)
c      WRITE(4,*)'V12=',V(1,2),'V13=',V(1,3),'V23=',V(2,3)
c      WRITE(4,*)'V21=',V(2,1),'V31=',V(3,1),'V32=',V(3,2)
c      stop 
C     ������������ ��������� ��� ����������� ������        
      DETER=1.D0/(E(1,1)*E(2,2)*E(3,3))*(1.D0-V(2,3)*V(3,2)-V(1,2)*
     *V(2,1)-V(2,1)*V(1,3)*V(3,2)-V(3,1)*V(1,2)*V(2,3)-V(1,3)*V(3,1))
      DD=1.D0/DETER
      A11=1.D0/(E(2,2)*E(3,3))*(1.D0-V(2,3)*V(3,2))*DD
      A12=1.D0/(E(1,1)*E(3,3))*(V(1,2)+V(1,3)*V(3,2))*DD
      A13=1.D0/(E(1,1)*E(2,2))*(V(1,2)*V(2,3)+V(1,3))*DD
      A21=1.D0/(E(2,2)*E(3,3))*(V(2,1)+V(3,1)*V(2,3))*DD
      A22=1.D0/(E(1,1)*E(3,3))*(1.D0-V(1,3)*V(3,1))*DD
      A23=1.D0/(E(1,1)*E(2,2))*(V(2,3)+V(2,1)*V(1,3))*DD
      A31=1.D0/(E(2,2)*E(3,3))*(V(2,1)*V(3,2)+V(3,1))*DD
      A32=1.D0/(E(1,1)*E(3,3))*(V(3,2)+V(3,1)*V(1,2))*DD
      A33=1.D0/(E(1,1)*E(2,2))*(1.D0-V(2,1)*V(1,2))*DD
C     ���������� ������������� ��������� (��� ��������)
c      write(4,*)'A11=',A11,'A21=',A21,'A31=',A31
c      write(4,*)'e=',ed
c      write(4,*)'A12=',A12,'A22=',A22,'A32=',A32
c      write(4,*)'A13=',A13,'A23=',A23,'A33=',A33 
C      STOP
C     ���� ����������� ������������ �������������
      S(1,1)=A11*ED(1,1)+A12*ED(2,2)+A13*ED(3,3)
      S(2,2)=A21*ED(1,1)+A22*ED(2,2)+A23*ED(3,3)
      S(3,3)=A31*ED(1,1)+A32*ED(2,2)+A33*ED(3,3)
      S(1,2)=2.D0*G(1,2)*ED(1,2) 
      S(2,1)=S(1,2) 
      S(1,3)=2.D0*G(1,3)*ED(1,3) 
      S(3,1)=S(1,3) 
      S(2,3)=2.D0*G(2,3)*ED(2,3) 
      S(3,2)=S(2,3)
c      write(4,*)'S',S
c      stop
      CALL ALBE(CK0,ALFA,BETA)
C      write(4,*) ALFA*180.D0/PI,BETA*180.D0/PI
      APOV(1,1)=DCOS(ALFA)*DCOS(BETA)
      APOV(1,2)=-DSIN(BETA)
      APOV(1,3)=-DSIN(ALFA)*DCOS(BETA)
      APOV(2,1)=DSIN(BETA)*DCOS(ALFA)
      APOV(2,2)=DCOS(BETA)
      APOV(2,3)=-DSIN(BETA)*DSIN(ALFA)
      APOV(3,1)=DSIN(ALFA)
      APOV(3,2)=0.D0
      APOV(3,3)=DCOS(ALFA)
C      write(4,*) APOV(1,1),APOV(1,2),APOV(1,3)
C      write(4,*) APOV(2,1),APOV(2,2),APOV(2,3)
C      write(4,*) APOV(3,1),APOV(3,2),APOV(3,3)
C      stop
      DO 11 I=1,3
      DO 11 J=1,3
      SS=0.D0
      DO 13 K=1,3
      DO 13 L=1,3
   13 SS=SS+S(K,L)*APOV(I,K)*APOV(J,L)
   11 SI(I,J)=SS
C      write(4,*) SI
C      stop
 1001 CONTINUE
      DO 1 I=1,3
      DO 1 J=1,3
      SS=0.D0
      DO 3 K=1,3
      DO 3 L=1,3
    3 SS=SS+SI(K,L)*CK0(I,K)*CK0(J,L)
      S(I,J)=SS
c      s(i,j)=si(i,j)
    1 continue 
C      write(4,*)S
C      stop
      RETURN
      END
      SUBROUTINE SIGARM(FI,CK0)
      DOUBLE PRECISION FI,APOV,SI,SS,CK0,pi
      DOUBLE PRECISION ALFA,BETA
      DIMENSION APOV(3,3),FI(3,3),SI(3,3),CK0(3,3)
      DATA APOV/9*0.D0/
      CALL ALBE(CK0,ALFA,BETA)
      PI=4.D0*DATAN(1.D0)
c      write(4,*) ALFA*180.D0/PI,BETA*180.D0/PI
      APOV(1,1)=DCOS(ALFA)*DCOS(BETA)
      APOV(1,2)=DSIN(BETA)*DCOS(ALFA)
      APOV(1,3)=DSIN(ALFA)
      APOV(2,1)=-DSIN(BETA)
      APOV(2,2)=DCOS(BETA)
      APOV(2,3)=0.D0
      APOV(3,1)=-DSIN(ALFA)*DCOS(BETA)
      APOV(3,2)=-DSIN(ALFA)*DSIN(BETA)
      APOV(3,3)=DCOS(ALFA)           
c      write(4,*) 'APOV'
c      write(4,*) APOV(1,1),APOV(1,2),APOV(1,3)
c      write(4,*) APOV(2,1),APOV(2,2),APOV(2,3)
c      write(4,*) APOV(3,1),APOV(3,2),APOV(3,3)
      DO 1 I=1,3
      DO 1 J=1,3
      SS=0.D0
      DO 3 K=1,3
      DO 3 L=1,3
    3 SS=SS+fI(K,L)*(CK0(K,I)*CK0(L,J))
      sI(I,J)=SS
c      SI(I,J)=fi(i,j)
    1 continue
      DO 11 I=1,3
      DO 11 J=1,3
      SS=0.D0
      DO 13 K=1,3
      DO 13 L=1,3
   13 SS=SS+si(K,L)*APOV(I,K)*APOV(J,L)
   11 fI(I,J)=SS
c      write(4,*) FI
c      stop
      RETURN
      END
      SUBROUTINE ALBE(CK0,ALFA,BETA)
      DOUBLE PRECISION CK0,AS,XT,XTM,CN0,PI,EPS
      DOUBLE PRECISION ALFA,BETA
      DOUBLE PRECISION XE1,XE2,XE3
      DIMENSION CK0(3,3),XT(3),XTM(3),CN0(3,3)
      COMMON/COORDEK/XE1,XE2,XE3
      PI=4.D0*DATAN(1.D0)
      EPS=0.00000001D0
      CALL KASAT(XT,XE1,XE2,XE3)
      CALL OBRM33(CK0,CN0)
      DO 1 I=1,3
      AS=0.D0
      DO 2 K=1,3
C      WRITE(4,*) 'cn0P=',XT(K)*CN0(I,K)
    2 AS=AS+XT(K)*CN0(I,K)
    1 XTM(I)=AS
C      WRITE(4,*) 'cn0=',cn0
C      WRITE(4,*) 'XE=',XE1,XE2,XE3
C      WRITE(4,*) 'XT=',XT(1),XT(2),XT(3)
C      WRITE(4,*) 'XTM=',XTM(1),XTM(2),XTM(3)
      IF(DABS(XTM(1)).LT.EPS.AND.DABS(XTM(2)).LT.EPS) alfa=PI/2.D0
      IF(DABS(XTM(1)).LT.EPS.AND.DABS(XTM(2)).LT.EPS) beta=0.D0
      IF(DABS(XTM(1)).LT.EPS.AND.DABS(XTM(2)).LT.EPS) GOTO 3
      IF(DABS(XTM(1)).LT.EPS) beta=PI/2.D0
      IF(DABS(XTM(1)).LT.EPS) GOTO 4
      beta=DATAN(XTM(2)/XTM(1))
    4 alfa=DATAN(XTM(3)/(DSQRT(XTM(1)**2+XTM(2)**2)))
    3 CONTINUE
c      write(4,*) ALFA*180.D0/PI,BETA*180.D0/PI
c      stop
      RETURN
      END
