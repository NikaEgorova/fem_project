C     TECT ������������ ����� �� �������������� ���������� 
C     O���E �EK�APAT�BH�E O�EPATOP� C�CTEM�
      COMMON/PARGAU/NEQQ,NST,NB,N
               COMMON/MAXNZZ/MAX,NZZ,NNP
               COMMON/DRIWG/LOA,TIME,NDRIW,ISUH
               COMMON/RABGAU/NNSL(9)
               COMMON/RESZAP/ITAPE(4),IDRUM(4)
               COMMON/KSO/LDK(8)/KKTI/KTI(3)
               COMMON/IUPR/MRE(4)/NEQ/NEQ
               COMMON/DIMS/M1,M2,M3
               COMMON/PARLIS/ILIS
               COMMON/NUSTR/NUS
               COMMON/OBMD/INZAP(3)
               COMMON/CATFIL/IC(150)
               COMMON/KV/KV
               COMMON/NVZ/NZM,NTB
               COMMON/MSKE/MSKE
               COMMON/MNLMCX/MNL,MCX
               COMMON IS
      DOUBLE PRECISION CSIL,SHAG,XN,CSI,AS
               COMMON/CSI/CSIL(20)
               COMMON/SHAGI/SHAG(60)
               COMMON/NACH/XN(3)
               COMMON/ACSI/CSI(3,10),AS(3,10)
               COMMON/ALV/ALV,BETA
               COMMON/OBM/AR(911)
C     �EK�APAT�BH�E O�EPATOP� 3-X MEPHO� �A�A��
      DOUBLE PRECISION DET,DETS,ALV,BETA
               COMMON/DET/DET
               COMMON/DETS/DETS
               COMMON/JN64/NN(64)
               COMMON/JN16/NNN(16)
               COMMON/NUKE/KU(16)
               COMMON/KSOS/MN(2)
               COMMON/NGR/IG(6)
C     �EK�APAT�BH�E O�EPATOP� TEPMO��P��OCT�
               COMMON/NUS/NUSSS
               COMMON/PRCILC/PREO,SVER,IPRI
               LOGICAL PREO,SVER
               COMMON/UVINO/UVIN,UTEM
               LOGICAL UVIN,UTEM
               COMMON/UPRO/UPRO
               LOGICAL UPRO
      DOUBLE PRECISION CORECT,UD,UVIS3,U,Q,X,umax,umin
               COMMON/CORECT/CORECT
               COMMON/N1930/N19(12)
C     O���E PA�O��E MACC�B� C�CTEM�
      DOUBLE PRECISION RM,RM1,T,AR
      DIMENSION RM(911),RM1(911)
      DIMENSION NF(1500),NG(1500),T(1500)
      DIMENSION Q(1500,3),X(1500,3),UD(1500,3)
      DIMENSION U(4500)
      DATA NF,NG,T/1500*-1,1500*-1,1500*0.D0/
      DATA RM,RM1/911*0.D0,911*0.D0/
      DATA X,Q,UD/13500*0.D0/
      DATA U/4500*0.D0/
C     �A�AH�E �APAMETPOB �A��OB �A��C�
      OPEN (4,FILE='DATA.TXT',STATUS='NEW')
      OPEN (8,STATUS='UNKNOWN',FORM='BINARY',
     *ACCESS='DIRECT',RECL=7288)
C     �A�AH�E O���X �APAMETPOB C�CTEM�
                 IS=1
                 NL=0
                 LOA=0
                 NUX=1500
C     B��OB �/� DTU3
      CALL DARMIR(X,NF,NG,T,Q,NUX)
                 MCX=MRE(2)
      NEQQ=NEQ
      NST=LDK(6)
      NB=LDK(5)
      NSTN=NST*NB+NL*NB
      NSB=NST*NB+1
      NMS=M1*M2*M3
      NES=(NEQ-1)/NB+1
c      nzm=ldk(8)+1
      call nmaq1(nf,ng,x,t,q,nux)
      utem=.false. 
C     �E�AT� TA����H�X �AHH�X 3-X MEP. TEPMO��P��OCT�
      CALL PECDA3(X,Q,T,NF,NG,NUX,NMS)
      WRITE(*,*)'�������� PECDA3'
c      STOP
	DO 111 I=1,NES+1
111	WRITE(ITAPE(1),REC=I) RM
C     �OPM�POBAH�E MATP��� 3-X MEP. TEPMO��P��OCT�
      CALL NMAKM(NF,NG,X,T,Q,NUX)
      WRITE(*,*)'�������� NMAKM'
C     O�PA�EH�E K �/� GASAL
      WRITE(*,*) '������� �������',NES
      CALL GASAL(RM(1),RM1(1),RM(NSB),RM1(NSB),NSTN)
C     �PABA� �ACT� TEPMO��P��OCT�
      DO 7 I=1,NMS
      IP=NF(I)
      IF(IP.LT.0)GOTO 7
      IPZ=IPRZAK(IP,II,JJ,KK)
      IF(II.EQ.1)Q(I,1)=0.D0
      IF(JJ.EQ.1)Q(I,2)=0.D0
      IF(KK.EQ.1)Q(I,3)=0.D0
    7 CONTINUE
      DO 1 I=1,NMS
      IP=NF(I)
      IF(IP.LT.0) GOTO 1
      MU=NG(I)
      DO 11 J=1,3
      NU=MU+J-1
      U(NU)=U(NU)+Q(I,J)
   11 CONTINUE
    1 CONTINUE
C     O�PA�EH�E K �/� GALOA
      WRITE(*,*) '�������� ���'
      CALL GALOA(RM,NSTN,U)
      umax=0.d0
      umin=0.d0
      DO 2 I=1,NMS
      MU=NG(I)
      IP=NF(I)
      IF(IP.LT.0) GOTO 2
      IPZ=IPRZAK(IP,II,JJ,KK)
      DO 22 J=1,3
      NU=MU+J-1
      UD(I,J)=U(NU)
      if(ud(i,j).gt.umax) numax=i
      if(ud(i,j).gt.umax) namax=j
      if(ud(i,j).gt.umax) umax=ud(i,j)
      if(ud(i,j).lt.umin) numin=i
      if(ud(i,j).lt.umin) namin=j
      if(ud(i,j).lt.umin) umin=ud(i,j)
      IF(.NOT.UVIN) GOTO 22
      IF(J.EQ.1.AND.II.EQ.1)UD(I,1)=UVIS3(I,1)
      IF(J.EQ.2.AND.JJ.EQ.1)UD(I,2)=UVIS3(I,2)
      IF(J.EQ.3.AND.KK.EQ.1)UD(I,3)=UVIS3(I,3)
   22 CONTINUE
    2 CONTINUE
      IF(PREO)CALL PREUCI(UD,NUX,NMS)
C     �E�AT� PE����TATOB PE�EH�� �-X MEP. TE�M-CT�
      CALL PRINKE(UD,X,T,NF,NUX,NMS)
      write(4,*)'umin=',umin,numin,namin
      write(4,*)'umax=',umax,numax,namax
      NZM=1
      END



