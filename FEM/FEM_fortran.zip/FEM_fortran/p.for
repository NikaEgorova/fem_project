      SUBROUTINE PRINKE(U,X,T,NF,NUX,NMS)
      DOUBLE PRECISION X,U(1),T(1),D,SIG,AT,SIH,
     *EN(9),SN(9),DN,A1
      DOUBLE PRECISION E11,E22,E33,G23,G21,G31
      DOUBLE PRECISION V23,V32,V21,V12,V31,V13
      COMMON/A1/A1
      COMMON/KAMOD/E11,E22,E33,G23,G21,G31
      COMMON/KAPUAS/V23,V32,V21,V12,V31,V13
      COMMON/HYDROS/SIH
      DIMENSION NF(1),D(9),SIG(9),X(1)
C      COMMON/JN64/NN(64)
      COMMON/DEFNEL/DN
      COMMON/DIMS/M1,M2,M3
      WRITE(4,*)'E11=',E11,'E22=',E22,'E33=',E33
      WRITE(4,*)'G12=',G21,'G13=',G31,'G23=',G23
      WRITE(4,*)'G21=',G21,'G31=',G31,'G32=',G23
      WRITE(4,*)'V12=',V12,'V13=',V13,'V23=',V23
      WRITE(4,*)'V21=',V21,'V31=',V31,'V32=',V32
      SIH=0.D0
      WRITE(4,10)
      WRITE(4,21)
      DO 1 I=1,NMS
      KS2=KOS(I,2)
      DO 33 K=1,1
      A1=0.D0
c      A1=2.D0*K-3.D0
      IF(NF(I).LT.10) GO TO 2
      IF(KS2.EQ.M2) GO TO 2
      CALL SIGKE3(U,X,T,NF,I,NUX,NMS,D,SIG,AT,EN,SN)
      DO 5 J=1,9
    5 SIG(J)=SIG(J)+SN(J)*DN
      GO TO 4
    2 CONTINUE
      DO 3 J=1,9
    3 SIG(J)=0.D0
    4 CONTINUE
      WRITE(4,20)I,U(I),U(I+NUX),U(I+NUX*2),DSQRT(U(I)**2+U(I+NUX)**2),
     *SIG(2),SIG(3),SIG(5),SIG(6),SIG(9)
   33 CONTINUE
    1 CONTINUE
   20 FORMAT(2X,I4,2X,9(1X,D12.5))
   21 FORMAT(4X,'NU',7X,'U1',11X,'U2',11X,'U3',11X,
     *'SG11',9X,'SG12',9X,'SG13',9X,'SG22',9X,
     *'SG23',9X,'SG33'/)
   10 FORMAT(///5X,'�O�� ���OB�X �EPEME�EH�� � ',
     *'HA�P��EH�� B �EHTPAX KOHE�H�X ��EMEHTOB ',
     *'B �EKAPTOBO� C�CTEME KOOP��HAT'//)
      RETURN
      END
      SUBROUTINE NUGLOB(X,NUX,J,NF,NG,L,NEQ)
      DOUBLE PRECISION X,A,B
      COMMON/DIMS/M1,M2,M3
      DIMENSION X(NUX,J),NF(1),NG(1)
    1 FORMAT(10X,'NEQ=',I5)
      NMS=M1*M2*M3
      LG=1-L
      B=0.000001D0
      DO 10 I=1,NMS
      IP=NF(I)
      IF(IP.LT.0)GO TO 10
      NGG=NG(I)
      IF(NGG.GT.0) GO TO 10
      LG=LG+L
      NG(I)=LG
      IPP=I+1
      IF(IPP.GT.NMS)GOTO 10
      DO 100 II=IPP,NMS
      IRR=NF(II)
      IF(IRR.LT.0) GO TO 100
      NGG=NG(II)
      IF(NGG.GT.0) GO TO 100
      JJ=1
      DO 200 KJ=1,J
      A=X(I,KJ)-X(II,KJ)
      A=DABS(A)
      IF(A.GT.B)JJ=0
  200 CONTINUE
      IF(JJ.EQ.1)NG(II)=LG
  100 CONTINUE
   10 CONTINUE
      NEQ=LG+L-1
      RETURN
      END
