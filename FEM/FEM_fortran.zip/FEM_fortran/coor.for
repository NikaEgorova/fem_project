      SUBROUTINE COOR(X,AL,O1,O2,O3)
      DOUBLE PRECISION AL,O1,O2,O3,X1,X2,X3,STX,SN,X,XE1,XE2,XE3
      DIMENSION SN(8),X(1),AL(1)
      COMMON/KSO/MM,NN,LL,LO(5)
      COMMON/COORDEK/XE1,XE2,XE3
      MNL=MM*NN*LL
      XE1=0.D0
      XE2=0.D0
      XE3=0.D0
      DO 1 K=1,LL
      DO 1 J=1,NN
      DO 1 I=1,MM
      IJK=I+MM*(J-1)+MM*NN*(K-1)
      SN(IJK)=0.D0
      DO 2 KK=1,LL
      DO 2 JJ=1,NN
      DO 2 II=1,MM
      IJK3=II+MM*(JJ-1)+MM*NN*(KK-1)+MNL*(IJK-1)
      X1=STX(II-1,O1)
      X2=STX(JJ-1,O2)
      X3=STX(KK-1,O3)
    2 SN(IJK)=SN(IJK)+AL(IJK3)*X1*X2*X3
      XE1=XE1+SN(IJK)*X(IJK)        
      XE2=XE2+SN(IJK)*X(MNL+IJK)
    1 XE3=XE3+SN(IJK)*X(2*MNL+IJK)   
C      WRITE(4,*) 'XEEE=',XE1,XE2,XE3
      RETURN
      END
